# Qt 海天鹰浮球
Linux 平台基于 Qt5 的网速浮窗，鼠标悬浮显示系统信息。  
desktop 放到 ~/.config/autostart 可以随系统启动。  
已编译好的 HTYFB 程序适用 64 位 Linux 系统 Qt5 环境，双击运行，其他版本请自行编译。  

![alt](preview.gif)

已知问题：  
窗口全屏不能隐藏。